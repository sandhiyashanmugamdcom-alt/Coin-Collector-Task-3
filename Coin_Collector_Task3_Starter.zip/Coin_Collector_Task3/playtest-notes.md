# Playtest Notes — Coin Collector

**Build tested:** ____________________  
**Date:** ____________________  
**Where/how was it tested?** ____________________

Ask all three participants the same questions. Record their actual answers; do not invent responses.

## Questions for every participant
1. Was the game easy to understand? Why or why not?
2. Were the controls comfortable and responsive?
3. Could you tell when you collected a coin or hit a rock?
4. Were the sound and accessibility settings easy to find and use?
5. What one improvement would you suggest?

## Participant 1
- Name or anonymous label:
- Device/browser:
- Q1:
- Q2:
- Q3:
- Q4:
- Q5:
- Observed difficulty or useful quote:

## Participant 2
- Name or anonymous label:
- Device/browser:
- Q1:
- Q2:
- Q3:
- Q4:
- Q5:
- Observed difficulty or useful quote:

## Participant 3
- Name or anonymous label:
- Device/browser:
- Q1:
- Q2:
- Q3:
- Q4:
- Q5:
- Observed difficulty or useful quote:

## Summary of findings
- Most common positive point:
- Most common problem:
- Highest-priority change:
- Change made after testing:
- How the change was checked:
