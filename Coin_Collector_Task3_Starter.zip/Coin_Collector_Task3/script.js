const SIZE = 7;
const TOTAL_COINS = 5;
const playerStart = { x: 0, y: 0 };
const walls = new Set(["2,1", "2,2", "4,2", "4,3", "1,4", "3,5", "5,5"]);
const coinStart = ["1,0", "5,0", "3,3", "0,5", "6,6"];

let player = { ...playerStart };
let coins = new Set(coinStart);
let score = 0;
let moves = 0;
let finished = false;
let audioContext = null;

const board = document.getElementById("board");
const scoreEl = document.getElementById("score");
const remainingEl = document.getElementById("remaining");
const movesEl = document.getElementById("moves");
const statusEl = document.getElementById("status");
const soundToggle = document.getElementById("soundToggle");
const motionToggle = document.getElementById("motionToggle");

function key(x, y) { return `${x},${y}`; }

function drawBoard() {
  board.innerHTML = "";
  for (let y = 0; y < SIZE; y++) {
    for (let x = 0; x < SIZE; x++) {
      const cell = document.createElement("div");
      cell.className = "cell";
      cell.setAttribute("role", "gridcell");
      cell.setAttribute("aria-label", `Row ${y + 1}, column ${x + 1}`);

      if (walls.has(key(x, y))) {
        cell.classList.add("wall");
        cell.textContent = "🪨";
        cell.setAttribute("aria-label", `Rock at row ${y + 1}, column ${x + 1}`);
      } else if (player.x === x && player.y === y) {
        cell.classList.add("player");
        cell.textContent = "🧑";
        cell.setAttribute("aria-label", "Player");
      } else if (coins.has(key(x, y))) {
        cell.classList.add("coin");
        cell.textContent = "🪙";
        cell.setAttribute("aria-label", "Coin");
      } else {
        cell.textContent = "·";
        cell.setAttribute("aria-label", "Empty space");
      }
      board.appendChild(cell);
    }
  }
  scoreEl.textContent = score;
  remainingEl.textContent = coins.size;
  movesEl.textContent = moves;
}

function playTone(frequency = 660, duration = 0.12) {
  if (!soundToggle.checked) return;
  try {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) return;
    audioContext = audioContext || new AudioContextClass();
    if (audioContext.state === "suspended") audioContext.resume();
    const oscillator = audioContext.createOscillator();
    const gain = audioContext.createGain();
    oscillator.type = "sine";
    oscillator.frequency.value = frequency;
    gain.gain.setValueAtTime(0.08, audioContext.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + duration);
    oscillator.connect(gain);
    gain.connect(audioContext.destination);
    oscillator.start();
    oscillator.stop(audioContext.currentTime + duration);
  } catch (error) {
    // The game remains playable if browser audio is unavailable.
  }
}

function move(direction) {
  if (finished) return;
  const delta = {
    up: [0, -1], down: [0, 1], left: [-1, 0], right: [1, 0]
  }[direction];
  if (!delta) return;

  const nextX = player.x + delta[0];
  const nextY = player.y + delta[1];
  moves++;

  if (nextX < 0 || nextX >= SIZE || nextY < 0 || nextY >= SIZE || walls.has(key(nextX, nextY))) {
    statusEl.textContent = "Blocked! Try another direction.";
    playTone(180, 0.08);
    const playerCell = board.children[player.y * SIZE + player.x];
    if (playerCell && !document.body.classList.contains("reduced-motion")) {
      playerCell.classList.add("bump");
      setTimeout(() => playerCell.classList.remove("bump"), 240);
    }
    movesEl.textContent = moves;
    return;
  }

  player = { x: nextX, y: nextY };
  if (coins.has(key(player.x, player.y))) {
    coins.delete(key(player.x, player.y));
    score += 10;
    statusEl.textContent = `Great job! Coin collected. Your score is ${score}.`;
    playTone(760, 0.18);
  } else {
    statusEl.textContent = "Nice move! Keep looking for coins.";
  }

  if (coins.size === 0) {
    finished = true;
    statusEl.textContent = `You win! You collected all ${TOTAL_COINS} coins in ${moves} moves.`;
    playTone(920, 0.35);
  }
  drawBoard();
}

function resetGame() {
  player = { ...playerStart };
  coins = new Set(coinStart);
  score = 0;
  moves = 0;
  finished = false;
  statusEl.textContent = "New game! Use the arrow keys or WASD to collect all 5 coins.";
  drawBoard();
}

document.addEventListener("keydown", (event) => {
  const directions = {
    ArrowUp: "up", w: "up", W: "up",
    ArrowDown: "down", s: "down", S: "down",
    ArrowLeft: "left", a: "left", A: "left",
    ArrowRight: "right", d: "right", D: "right"
  };
  const direction = directions[event.key];
  if (direction) {
    event.preventDefault();
    move(direction);
  }
});

document.querySelectorAll("[data-move]").forEach((button) => {
  button.addEventListener("click", () => move(button.dataset.move));
});

document.getElementById("resetButton").addEventListener("click", resetGame);
motionToggle.addEventListener("change", () => {
  document.body.classList.toggle("reduced-motion", motionToggle.checked);
});

drawBoard();
