# Before-and-After Evidence — Coin Collector

Use this report to explain changes made after testing. Replace every prompt with what you actually observed and changed.

## Before playtesting
- Build/version:
- Features already implemented:
- Screenshot filename or evidence link:

## Findings from playtesting
| Issue observed | How many testers mentioned/experienced it? | Evidence |
|---|---:|---|
| [Record an actual issue] | [0–3] | [Quote, observation or screenshot] |
| [Record an actual issue] | [0–3] | [Quote, observation or screenshot] |

## Changes made
| Before | Change implemented | After / evidence |
|---|---|---|
| [Describe the real problem] | [Describe the code or design change] | [Explain how you verified it] |

## Final check
- [ ] Keyboard controls tested.
- [ ] Visible focus tested using Tab and Shift+Tab.
- [ ] Sound can be turned off.
- [ ] Reduced-motion option tested.
- [ ] Game tested at desktop and mobile widths.
- [ ] At least three real playtests recorded.
- [ ] Screenshots or recording added, if available.

## Reflection
What did you learn from the playtest, and what would you improve next?
[Write your reflection here.]
