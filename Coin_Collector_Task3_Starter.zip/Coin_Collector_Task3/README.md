# Coin Collector — Game Development Task 3

A small browser game built with HTML, CSS and JavaScript for the task **Game Feel, Accessibility, and Playtest**.

## Play the game
Open `index.html` in a modern web browser. No installation or server is required.

## Controls
- Arrow keys or W, A, S, D to move.
- On-screen arrow buttons also work.
- Collect all 5 coins (10 points each).
- Rocks block movement.
- Select **Restart game** to start again.

## Accessibility and game-feel features
- Keyboard controls.
- Visible focus indicators for buttons and settings.
- Sound effects checkbox (sound is enabled by default).
- Reduced-motion checkbox.
- Status updates announced through an ARIA live region.
- Responsive layout for smaller screens.
- Visual feedback for coin collection and blocked movement.

## Project files
- `index.html` — page structure and game interface.
- `style.css` — layout, colors, focus styles and responsive design.
- `script.js` — game rules, keyboard input, sound and feedback.
- `playtest-notes.md` — template to record three real playtesters.
- `before-after.md` — template to document evidence-based improvements.

## Playtesting
Ask at least three people to play the game. Ask each person the same questions and record their actual answers in `playtest-notes.md`. Do not submit example or invented feedback as real results.

## Before-and-after evidence
Record the real issue found, the change made, and evidence that the change improved the experience in `before-after.md`. Add screenshots or a short screen recording to this repository if available.

## Submission
Make the GitHub repository public, check that the files open without requesting access, and submit the repository URL as the single proof link.
